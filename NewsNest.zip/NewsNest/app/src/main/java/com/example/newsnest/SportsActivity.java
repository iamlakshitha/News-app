package com.example.newsnest;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.newsnest.R;

public class SportsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);
    }
}