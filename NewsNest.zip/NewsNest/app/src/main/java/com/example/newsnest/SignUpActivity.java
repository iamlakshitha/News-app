package com.yourapp.newsnest;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.newsnest.HomeActivity;
import com.example.newsnest.R;

public class SignUpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        findViewById(R.id.btnSignUp).setOnClickListener(v -> {
            startActivity(new Intent(SignUpActivity.this, HomeActivity.class));
            finish();
        });
    }
}