package com.yourapp.newsnest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import com.example.newsnest.HomeActivity;
import com.example.newsnest.R;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            finish();
        });

        findViewById(R.id.btnSignUp).setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, com.yourapp.newsnest.SignUpActivity.class));
        });
    }
}