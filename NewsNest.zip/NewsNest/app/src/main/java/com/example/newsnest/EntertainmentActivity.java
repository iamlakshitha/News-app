package com.example.newsnest;

public class EntertainmentActivity {
}
